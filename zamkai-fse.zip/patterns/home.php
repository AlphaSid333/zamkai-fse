<?php
/**
 * Title: Home
 * Slug: zamkai-fse/home
 * Categories: home
 */
?>
<!-- wp:pattern { "slug":"zamkai-fse/hero" } /-->
<!-- wp:pattern { "slug":"zamkai-fse/featured-stats" } /-->
<!-- wp:pattern { "slug":"zamkai-fse/poem" } /-->
<!-- wp:pattern { "slug":"zamkai-fse/poem-2" } /-->